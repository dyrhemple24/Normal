player_position = (10, 10)
target_position = (30, 20)
sensitivity = 1.5

adjusted_target = aim_assist(player_position, target_position, sensitivity)
print("Angepasste Zielposition:", adjusted_target)
