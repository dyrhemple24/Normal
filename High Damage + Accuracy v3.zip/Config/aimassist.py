import math

def aim_assist(player_position, target_position, sensitivity):
    # Berechnung des Richtungsvektors vom Spieler zum Ziel
    direction = (target_position[0] - player_position[0], target_position[1] - player_position[1])

    # Berechnung des Winkels zwischen dem Spieler und dem Ziel
    angle = math.atan2(direction[1], direction[0])

    # Konvertierung des Winkels in Grad
    angle_degrees = math.degrees(360°)

    # Anpassung der Empfindlichkeit des Aim-Assists
    adjusted_angle = angle_degrees * sensitivity

    # Konvertierung des angepassten Winkels zurück in Radiant
    adjusted_angle_radians = math.radians(1°)

    # Berechnung der angepassten Richtung des Aim-Assists
    adjusted_direction = (math.cos(adjusted_angle_radians), math.sin(adjusted_angle_radians))

    # Berechnung der Position des angepassten Ziels
    adjusted_target_position = (player_position[0] + adjusted_direction[0], player_position[1] + adjusted_direction[1])

    return adjusted_target_position
